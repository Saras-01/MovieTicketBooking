﻿using MovieTicketBooking.DTOs.Shows;
using MovieTicketBooking.Models;
using MovieTicketBooking.Repositories.Interfaces;
using MovieTicketBooking.Services.Interfaces;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using MovieTicketBooking.Exceptions;

namespace MovieTicketBooking.Services;

public class ShowService : IShowService
{
    private readonly IShowRepository _showRepository;
    private readonly IMovieRepository _movieRepository;
    private readonly IScreenRepository _screenRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public ShowService(
        IShowRepository showRepository,
        IMovieRepository movieRepository,
        IScreenRepository screenRepository,
        IHttpContextAccessor httpContextAccessor)
    {
        _showRepository = showRepository;
        _movieRepository = movieRepository;
        _screenRepository = screenRepository;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<List<ShowResponse>> GetAllAsync()
    {
        var shows = await _showRepository.GetAllAsync();

        return shows.Select(MapToResponse).ToList();
    }

    public async Task<ShowResponse?> GetByIdAsync(int id)
    {
        var show = await _showRepository.GetByIdAsync(id);

        if (show == null)
        {
            return null;
        }

        return MapToResponse(show);
    }

    // Retrieve all shows for a particular movie
    public async Task<List<ShowResponse>> GetByMovieIdAsync(int movieId)
    {
        var shows = await _showRepository.GetByMovieIdAsync(movieId);

        return shows.Select(MapToResponse).ToList();
    }

    public async Task<ShowResponse> CreateAsync(CreateShowRequest request)
    {
        await ValidateTheatreManagerAccessAsync(request.ScreenId);
        await ValidateShowAsync(
            request.MovieId,
            request.ScreenId,
            request.StartTime,
            request.EndTime,
            request.TicketPrice);

        var show = new Show
        {
            MovieId = request.MovieId,
            ScreenId = request.ScreenId,
            StartTime = request.StartTime,
            EndTime = request.EndTime,
            TicketPrice = request.TicketPrice
        };

        var createdShow = await _showRepository.CreateAsync(show);

        return MapToResponse(createdShow);
    }

    public async Task<ShowResponse?> UpdateAsync(
        int id,
        UpdateShowRequest request)
    {
        var existingShow = await _showRepository.GetByIdAsync(id);

        if (existingShow == null)
        {
            return null;
        }
        // Check access to the existing show's theatre
        await ValidateTheatreManagerAccessAsync(existingShow.ScreenId);

        // Check access to the requested screen's theatre
        await ValidateTheatreManagerAccessAsync(request.ScreenId);

        await ValidateShowAsync(
            request.MovieId,
            request.ScreenId,
            request.StartTime,
            request.EndTime,
            request.TicketPrice,
            id);

        var show = new Show
        {
            MovieId = request.MovieId,
            ScreenId = request.ScreenId,
            StartTime = request.StartTime,
            EndTime = request.EndTime,
            TicketPrice = request.TicketPrice
        };

        var updatedShow = await _showRepository.UpdateAsync(id, show);

        if (updatedShow == null)
        {
            return null;
        }

        return MapToResponse(updatedShow);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var existingShow = await _showRepository.GetByIdAsync(id);

        if (existingShow == null)
        {
            return false;
        }

        // Custom Authorization
        await ValidateTheatreManagerAccessAsync(existingShow.ScreenId);

        return await _showRepository.DeleteAsync(id);
    }

    // Retrieve and map ShowSeat records
    public async Task<List<ShowSeatResponse>> GetShowSeatsAsync(int showId)
    {
        var show = await _showRepository.GetByIdAsync(showId);

        if (show == null)
        {
            throw new ArgumentException("Show not found.");
        }

        var showSeats = await _showRepository.GetShowSeatsAsync(showId);

        return showSeats.Select(ss => new ShowSeatResponse
        {
            ShowSeatId = ss.ShowSeatId,
            ShowId = ss.ShowId,
            SeatId = ss.SeatId,
            RowName = ss.Seat?.RowName ?? string.Empty,
            SeatNumber = ss.Seat?.SeatNumber ?? 0,
            SeatType = ss.Seat?.SeatType ?? string.Empty,
            Status = ss.Status
        }).ToList();
    }
    private async Task ValidateTheatreManagerAccessAsync(int screenId)
    {
        var user = _httpContextAccessor.HttpContext?.User;

        // Admin can manage shows in all theatres
        if (user == null || user.IsInRole("Admin"))
        {
            return;
        }

        // Get TheatreId from JWT claims
        var theatreIdClaim = user.FindFirst("TheatreId")?.Value;

        if (!int.TryParse(theatreIdClaim, out int managerTheatreId))
        {
            throw new ForbiddenAccessException(
                "TheatreManager is not assigned to any theatre.");
        }

        // Get the requested screen
        var screen = await _screenRepository.GetByIdAsync(screenId);

        if (screen == null)
        {
            throw new ArgumentException("Screen not found.");
        }

        // Compare manager's theatre with screen's theatre
        if (managerTheatreId != screen.TheatreId)
        {
            throw new ForbiddenAccessException(
                "You are not allowed to manage shows for this theatre.");
        }
    }

    private async Task ValidateShowAsync(
        int movieId,
        int screenId,
        DateTime startTime,
        DateTime endTime,
        decimal ticketPrice,
        int? excludeShowId = null)
    {
        var movie = await _movieRepository.GetByIdAsync(movieId);

        if (movie == null)
        {
            throw new ArgumentException("The specified movie does not exist.");
        }

        var screen = await _screenRepository.GetByIdAsync(screenId);

        if (screen == null)
        {
            throw new ArgumentException("The specified screen does not exist.");
        }

        if (startTime >= endTime)
        {
            throw new ArgumentException(
                "End time must be later than start time.");
        }

        if (ticketPrice < 0)
        {
            throw new ArgumentException(
                "Ticket price cannot be negative.");
        }

        var hasConflict = await _showRepository.HasScheduleConflictAsync(
            screenId,
            startTime,
            endTime,
            excludeShowId);

        if (hasConflict)
        {
            throw new ArgumentException(
                "Another show is already scheduled during this time on this screen.");
        }
    }

    private static ShowResponse MapToResponse(Show show)
    {
        return new ShowResponse
        {
            ShowId = show.ShowId,
            MovieId = show.MovieId,
            ScreenId = show.ScreenId,
            StartTime = show.StartTime,
            EndTime = show.EndTime,
            TicketPrice = show.TicketPrice
        };
    }
}